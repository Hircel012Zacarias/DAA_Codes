# -*- coding: utf-8 -*-
"""
Created on Thu Sep  4 09:31:07 2025

@author: cirze
"""

#Bubble Sort
def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:
            break
    return arr
arr=[1,4,2,1,6,4,2,7,3,4]
arr_sorted = bubble_sort(arr)
print("Sorted array:", arr_sorted)
